self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\app\\layout.tsx": [
      "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Ubuntu\",\"arguments\":[{\"weight\":[\"400\",\"700\",\"500\",\"300\"],\"style\":\"normal\",\"subsets\":[\"latin\"]}],\"variableName\":\"ubuntu\"}",
      "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\app\\globals.css"
    ]
  },
  "cssModules": {
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\app\\page": [
      "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\app\\globals.css",
      "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Ubuntu\",\"arguments\":[{\"weight\":[\"400\",\"700\",\"500\",\"300\"],\"style\":\"normal\",\"subsets\":[\"latin\"]}],\"variableName\":\"ubuntu\"}"
    ]
  }
}