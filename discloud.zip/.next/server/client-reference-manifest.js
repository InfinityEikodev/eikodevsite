self.__RSC_MANIFEST={
  "ssrModuleMapping": {
    "(app-client)/./node_modules/next/dist/client/components/app-router.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "getServerActionDispatcher": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "getServerActionDispatcher",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "urlToUrlWithoutFlightMarker": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "urlToUrlWithoutFlightMarker",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "TODO-APP": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "TODO-APP",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "__NA": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "__NA",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "location": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "location",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "\"http": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "\"http",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "searchParams": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "searchParams",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "pathname": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "pathname",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "type": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "type",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "cache": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "cache",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "status": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "status",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "data": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "data",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "subTreeData": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "subTreeData",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "parallelRoutes": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "parallelRoutes",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "mutable": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "mutable",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "isExternalUrl": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "isExternalUrl",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "locationSearch": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "locationSearch",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "back": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "back",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "forward": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "forward",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "prefetch": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "prefetch",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "kind": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "kind",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "replace": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "replace",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "push": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "push",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "refresh": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "refresh",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "origin": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "origin",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "fastRefresh": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "fastRefresh",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "router": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "router",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "(eg": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "(eg",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "url": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "url",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "tree": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "tree",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "notFound": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "notFound",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "notFoundStyles": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "notFoundStyles",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "asNotFound": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "asNotFound",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "pushRef": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "pushRef",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "canonicalUrl": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "canonicalUrl",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "sync": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "sync",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "value": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "value",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "childNodes": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "childNodes",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "assetPrefix": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "assetPrefix",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "errorComponent": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/app-router.js",
        "name": "errorComponent",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/error-boundary.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "ErrorBoundaryHandler": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "ErrorBoundaryHandler",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "ErrorBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "ErrorBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "error": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "error",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "https": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "https",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "fontFamily": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "fontFamily",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "height": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "height",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "textAlign": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "textAlign",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "display": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "display",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "flexDirection": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "flexDirection",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "alignItems": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "alignItems",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "justifyContent": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "justifyContent",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "desc": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "desc",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "text": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "text",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "fontSize": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "fontSize",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "fontWeight": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "fontWeight",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "lineHeight": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "lineHeight",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "margin": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "margin",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "reset": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "reset",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "style": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "style",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "\"Digest": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "\"Digest",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "errorComponent": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "errorComponent",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "errorStyles": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "errorStyles",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "value": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/error-boundary.js",
        "name": "value",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "RedirectErrorBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "RedirectErrorBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "RedirectBoundary": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "RedirectBoundary",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "redirect": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "redirect",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "redirectType": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "redirectType",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "reset": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "reset",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "router": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "router",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "value": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/redirect-boundary.js",
        "name": "value",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "*",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
        "name": "default",
        "chunks": [
          "webpack:static/chunks/webpack.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/layout-router.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/layout-router.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/render-from-template-context.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    },
    "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js": {
      "*": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "*",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      },
      "default": {
        "id": "(sc_client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
        "name": "default",
        "chunks": [
          "app-client-internals:static/chunks/app-client-internals.js"
        ],
        "async": false
      }
    }
  },
  "edgeSSRModuleMapping": {},
  "cssFiles": {
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\app\\layout": [
      "static/css/app/layout.css"
    ]
  },
  "clientModules": {
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#getServerActionDispatcher": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "getServerActionDispatcher",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#getServerActionDispatcher": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "getServerActionDispatcher",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#urlToUrlWithoutFlightMarker": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "urlToUrlWithoutFlightMarker",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#urlToUrlWithoutFlightMarker": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "urlToUrlWithoutFlightMarker",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#TODO-APP": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "TODO-APP",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#TODO-APP": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "TODO-APP",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#__NA": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "__NA",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#__NA": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "__NA",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#location": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "location",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#location": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "location",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#\"http": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "\"http",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#\"http": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "\"http",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#searchParams": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "searchParams",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#searchParams": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "searchParams",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#pathname": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "pathname",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#pathname": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "pathname",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#type": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "type",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#type": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "type",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#cache": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "cache",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#cache": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "cache",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#status": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "status",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#status": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "status",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#data": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "data",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#data": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "data",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#subTreeData": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "subTreeData",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#subTreeData": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "subTreeData",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#parallelRoutes": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "parallelRoutes",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#parallelRoutes": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "parallelRoutes",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#mutable": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "mutable",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#mutable": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "mutable",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#isExternalUrl": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "isExternalUrl",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#isExternalUrl": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "isExternalUrl",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#locationSearch": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "locationSearch",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#locationSearch": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "locationSearch",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#back": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "back",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#back": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "back",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#forward": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "forward",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#forward": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "forward",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#prefetch": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "prefetch",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#prefetch": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "prefetch",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#kind": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "kind",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#kind": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "kind",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#replace": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "replace",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#replace": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "replace",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#push": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "push",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#push": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "push",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#refresh": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "refresh",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#refresh": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "refresh",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#origin": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "origin",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#origin": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "origin",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#fastRefresh": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "fastRefresh",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#fastRefresh": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "fastRefresh",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#router": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "router",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#router": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "router",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#(eg": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "(eg",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#(eg": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "(eg",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#url": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "url",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#url": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "url",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#tree": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "tree",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#tree": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "tree",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#notFound": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "notFound",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#notFound": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "notFound",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#notFoundStyles": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "notFoundStyles",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#notFoundStyles": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "notFoundStyles",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#asNotFound": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "asNotFound",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#asNotFound": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "asNotFound",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#pushRef": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "pushRef",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#pushRef": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "pushRef",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#canonicalUrl": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "canonicalUrl",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#canonicalUrl": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "canonicalUrl",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#sync": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "sync",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#sync": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "sync",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#value": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "value",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#value": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "value",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#childNodes": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "childNodes",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#childNodes": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "childNodes",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#assetPrefix": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "assetPrefix",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#assetPrefix": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "assetPrefix",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\app-router.js#errorComponent": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "errorComponent",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\app-router.js#errorComponent": {
      "id": "(app-client)/./node_modules/next/dist/client/components/app-router.js",
      "name": "errorComponent",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#ErrorBoundaryHandler": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundaryHandler",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#ErrorBoundaryHandler": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundaryHandler",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#ErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#ErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "ErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#error": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "error",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#error": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "error",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#https": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "https",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#https": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "https",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#fontFamily": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "fontFamily",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#fontFamily": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "fontFamily",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#height": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "height",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#height": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "height",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#textAlign": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "textAlign",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#textAlign": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "textAlign",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#display": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "display",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#display": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "display",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#flexDirection": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "flexDirection",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#flexDirection": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "flexDirection",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#alignItems": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "alignItems",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#alignItems": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "alignItems",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#justifyContent": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "justifyContent",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#justifyContent": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "justifyContent",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#desc": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "desc",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#desc": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "desc",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#text": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "text",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#text": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "text",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#fontSize": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "fontSize",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#fontSize": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "fontSize",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#fontWeight": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "fontWeight",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#fontWeight": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "fontWeight",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#lineHeight": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "lineHeight",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#lineHeight": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "lineHeight",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#margin": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "margin",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#margin": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "margin",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#reset": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "reset",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#reset": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "reset",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#style": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "style",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#style": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "style",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#\"Digest": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "\"Digest",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#\"Digest": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "\"Digest",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#errorComponent": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "errorComponent",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#errorComponent": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "errorComponent",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#errorStyles": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "errorStyles",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#errorStyles": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "errorStyles",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\error-boundary.js#value": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "value",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\error-boundary.js#value": {
      "id": "(app-client)/./node_modules/next/dist/client/components/error-boundary.js",
      "name": "value",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#RedirectErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#RedirectErrorBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectErrorBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#RedirectBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#RedirectBoundary": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "RedirectBoundary",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#redirect": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "redirect",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#redirect": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "redirect",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#redirectType": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "redirectType",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#redirectType": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "redirectType",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#reset": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "reset",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#reset": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "reset",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#router": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "router",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#router": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "router",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\redirect-boundary.js#value": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "value",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\redirect-boundary.js#value": {
      "id": "(app-client)/./node_modules/next/dist/client/components/redirect-boundary.js",
      "name": "value",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\router-reducer\\fetch-server-response.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\router-reducer\\fetch-server-response.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/router-reducer/fetch-server-response.js",
      "name": "default",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#CacheStates": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "CacheStates",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#CacheStates": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "CacheStates",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#AppRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "AppRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#AppRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "AppRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#LayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "LayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#LayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "LayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#GlobalLayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "GlobalLayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#GlobalLayoutRouterContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "GlobalLayoutRouterContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\app-router-context.js#TemplateContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "TemplateContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\app-router-context.js#TemplateContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/app-router-context.js",
      "name": "TemplateContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#SearchParamsContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "SearchParamsContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#SearchParamsContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "SearchParamsContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\hooks-client-context.js#PathnameContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "PathnameContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\hooks-client-context.js#PathnameContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/hooks-client-context.js",
      "name": "PathnameContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "*",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#ServerInsertedHTMLContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "ServerInsertedHTMLContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#ServerInsertedHTMLContext": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "ServerInsertedHTMLContext",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\shared\\lib\\server-inserted-html.js#useServerInsertedHTML": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "useServerInsertedHTML",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\shared\\lib\\server-inserted-html.js#useServerInsertedHTML": {
      "id": "(app-client)/./node_modules/next/dist/shared/lib/server-inserted-html.js",
      "name": "useServerInsertedHTML",
      "chunks": [
        "webpack:static/chunks/webpack.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\layout-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\layout-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\layout-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\layout-router.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/layout-router.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\render-from-template-context.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\render-from-template-context.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/render-from-template-context.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "*",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js#": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\client\\components\\static-generation-searchparams-bailout-provider.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\dist\\esm\\client\\components\\static-generation-searchparams-bailout-provider.js#default": {
      "id": "(app-client)/./node_modules/next/dist/client/components/static-generation-searchparams-bailout-provider.js",
      "name": "default",
      "chunks": [
        "app-client-internals:static/chunks/app-client-internals.js"
      ],
      "async": false
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\app\\globals.css#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    },
    "C:\\Users\\samue\\Downloads\\Eiko-dev-2\\node_modules\\next\\font\\google\\target.css?{\"path\":\"app\\\\layout.tsx\",\"import\":\"Ubuntu\",\"arguments\":[{\"weight\":[\"400\",\"700\",\"500\",\"300\"],\"style\":\"normal\",\"subsets\":[\"latin\"]}],\"variableName\":\"ubuntu\"}#": {
      "id": "null",
      "name": "default",
      "chunks": [
        "static/css/app/layout.css"
      ]
    }
  }
}